import { Component, NgModule } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
nome: string = 'Ruan'
sobrenome: string = 'Santos'
senha: string= ''

  constructor() {}

}
