import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  //Variáveis de escopo global
  display = "";
  memoria = "";
  operacao = "";
  usouPonto = false;

  constructor() {}

  usarPonto(){
    if(this.display === ''){
      this.display = '0';
    }

    if(this.usouPonto === false){
      this.display = this.display + '.';
      this.usouPonto = true;
    }
  }

  escolherOperacao(operacao: string){
    if(this.display !== ''){
      this.memoria = this.display;
      this.display = "";
      this.operacao = operacao;

      this.usouPonto = false;
    }

    //console.log é opcional
    console.log("Memória: " + this.memoria);
    console.log("Operação escolhida: " + this.operacao)
  }

  efetuarCalculo(){
    if(this.display === ''){
      this.display = this.memoria;
      this.operacao = '';
    }else{
      switch(this.operacao){
        case '+': this.somar(); break;
        case '-': this.subtrair(); break;
        case '*': this.multiplicar(); break;
        case '/': this.dividir(); break;
      }
    }
  }

  multiplicar(){
    let n1 = parseFloat(this.memoria);
    let n2 = parseFloat(this.display);
    let resp = n1 * n2;

    this.display = resp.toString();
  }

  dividir(){
    let n1 = parseFloat(this.memoria);
    let n2 = parseFloat(this.display);

    if(n2 === 0){
      this.display = 'Erro de divisão';
    }else{
      let resp = n1 / n2;

      this.display = resp.toString();
    }
  }

  subtrair(){
    let n1 = parseFloat(this.memoria);
    let n2 = parseFloat(this.display);
    let resp = n1 - n2;

    this.display = resp.toString();
  }

  somar(){
    let n1 = parseFloat(this.memoria);
    let n2 = parseFloat(this.display);
    let resp = n1 + n2;

    this.display = resp.toString();
  }

  limpar(){
    this.display = "";
  }

  clicar(numero: string){
    this.display = this.display + numero;
  }
}
